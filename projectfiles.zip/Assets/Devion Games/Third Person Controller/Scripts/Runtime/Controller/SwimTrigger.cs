﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace DevionGames
{
	//Should be deprecated
	public class SwimTrigger:MotionTrigger
	{

	}
}