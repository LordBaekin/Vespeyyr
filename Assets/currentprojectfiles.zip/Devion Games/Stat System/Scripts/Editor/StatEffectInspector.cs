﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace DevionGames.StatSystem
{
    [CustomEditor(typeof(StatEffect),true)]
    public class StatEffectInspector : ActionInspector
    {
        
    }
}