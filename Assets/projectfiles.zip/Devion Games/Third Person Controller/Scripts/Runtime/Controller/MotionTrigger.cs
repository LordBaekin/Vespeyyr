﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace DevionGames
{
    public class MotionTrigger : MonoBehaviour
    {
        [InspectorLabel("Trigger")]
        public string triggerName = "Motion";
    }
}