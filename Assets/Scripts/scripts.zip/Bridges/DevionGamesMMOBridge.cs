﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UnityEngine;
using DevionGames.InventorySystem;
using DevionGames.StatSystem;
using DevionGames.CharacterSystem;
using DevionGames.QuestSystem;
using DevionGames.LoginSystem;
using TagDebugSystem;

public class DevionGamesMMOBridge : MonoBehaviour
{
    [Header("Containers")]
    public ItemContainer inventory;
    public ItemContainer equipment;
    public ItemContainer bank;
    public ItemContainer hotbar;

    [Header("Managers")]
    public StatsHandler statsHandler;
    public CharacterManager characterManager;
    public QuestManager questManager;
    public LoginManager loginManager;

    // --- Inventory Sync ---
    public async Task SyncInventoryFromServerAsync()
    {
        TD.Info(Tags.Inventory, "SyncInventoryFromServerAsync called.", this);
        var items = await DevionGamesServerApi.GetInventoryAsync();
        TD.Verbose(Tags.Inventory, $"Fetched {items.Count} inventory items from server.", this);
        SyncContainerFromServer(inventory, items);
        TD.Info(Tags.Inventory, "Inventory sync complete.", this);
    }
    public async Task PushInventoryToServerAsync()
    {
        TD.Info(Tags.Inventory, "PushInventoryToServerAsync called.", this);
        var items = CollectContainerItems(inventory);
        await DevionGamesServerApi.SetInventoryAsync(items);
        TD.Info(Tags.Inventory, $"Pushed {items.Count} inventory items to server.", this);
    }

    // --- Equipment Sync ---
    public async Task SyncEquipmentFromServerAsync()
    {
        TD.Info(Tags.Inventory, "SyncEquipmentFromServerAsync called.", this);
        var items = await DevionGamesServerApi.GetEquipmentAsync();
        TD.Verbose(Tags.Inventory, $"Fetched {items.Count} equipment items from server.", this);
        SyncContainerFromServer(equipment, items);
        TD.Info(Tags.Inventory, "Equipment sync complete.", this);
    }
    public async Task PushEquipmentToServerAsync()
    {
        TD.Info(Tags.Inventory, "PushEquipmentToServerAsync called.", this);
        var items = CollectContainerItems(equipment);
        await DevionGamesServerApi.SetEquipmentAsync(items);
        TD.Info(Tags.Inventory, $"Pushed {items.Count} equipment items to server.", this);
    }

    // --- Bank Sync ---
    public async Task SyncBankFromServerAsync()
    {
        TD.Info(Tags.Inventory, "SyncBankFromServerAsync called.", this);
        var items = await DevionGamesServerApi.GetBankAsync();
        TD.Verbose(Tags.Inventory, $"Fetched {items.Count} bank items from server.", this);
        SyncContainerFromServer(bank, items);
        TD.Info(Tags.Inventory, "Bank sync complete.", this);
    }
    public async Task PushBankToServerAsync()
    {
        TD.Info(Tags.Inventory, "PushBankToServerAsync called.", this);
        var items = CollectContainerItems(bank);
        await DevionGamesServerApi.SetBankAsync(items);
        TD.Info(Tags.Inventory, $"Pushed {items.Count} bank items to server.", this);
    }

    // --- Hotbar Sync ---
    public async Task SyncHotbarFromServerAsync()
    {
        TD.Info(Tags.Inventory, "SyncHotbarFromServerAsync called.", this);
        var items = await DevionGamesServerApi.GetHotbarAsync();
        TD.Verbose(Tags.Inventory, $"Fetched {items.Count} hotbar items from server.", this);
        SyncContainerFromServer(hotbar, items);
        TD.Info(Tags.Inventory, "Hotbar sync complete.", this);
    }
    public async Task PushHotbarToServerAsync()
    {
        TD.Info(Tags.Inventory, "PushHotbarToServerAsync called.", this);
        var items = CollectContainerItems(hotbar);
        await DevionGamesServerApi.SetHotbarAsync(items);
        TD.Info(Tags.Inventory, $"Pushed {items.Count} hotbar items to server.", this);
    }

    // --- Stats Sync ---
    public async Task SyncStatsFromServerAsync()
    {
        TD.Info(Tags.Stats, "SyncStatsFromServerAsync called.", this);
        var stats = await DevionGamesServerApi.GetStatsAsync();
        foreach (var statData in stats)
        {
            var stat = statsHandler.m_Stats.FirstOrDefault(x => x.Name == statData.statName);
            if (stat != null)
            {
                var dict = new Dictionary<string, object> { { "BaseValue", statData.value } };
                stat.SetObjectData(dict);
                TD.Verbose(Tags.Stats, $"Synced stat: {stat.Name} => {statData.value}", this);
            }
            else
            {
                TD.Warning(Tags.Stats, $"Stat not found: {statData.statName}", this);
            }
        }
        TD.Info(Tags.Stats, "Stats sync complete.", this);
    }
    public async Task PushStatsToServerAsync()
    {
        TD.Info(Tags.Stats, "PushStatsToServerAsync called.", this);
        var stats = statsHandler.m_Stats.Select(s => new StatData { statName = s.Name, value = s.Value }).ToList();
        await DevionGamesServerApi.SetStatsAsync(stats);
        TD.Info(Tags.Stats, $"Pushed {stats.Count} stats to server.", this);
    }

    // --- Quest Sync ---
    public async Task SyncQuestsFromServerAsync()
    {
        TD.Info(Tags.Quest, "SyncQuestsFromServerAsync called.", this);
        var quests = await DevionGamesServerApi.GetQuestsAsync();
        TD.Verbose(Tags.Quest, $"Fetched {quests.Count} quests from server.", this);
        questManager.ActiveQuests.Clear();
        foreach (var q in quests)
        {
            Quest questDef = QuestManager.current.AllQuests.FirstOrDefault(x => x.Name == q.questId);
            if (questDef != null)
            {
                if (!questManager.ActiveQuests.Contains(questDef))
                {
                    questManager.ActiveQuests.Add(questDef);
                    TD.Verbose(Tags.Quest, $"Synced quest: {questDef.Name}", this);
                }
            }
            else
            {
                TD.Warning(Tags.Quest, $"Quest not found in database: {q.questId}", this);
            }
        }
        TD.Info(Tags.Quest, "Quest sync complete.", this);
    }
    public async Task PushQuestsToServerAsync()
    {
        TD.Info(Tags.Quest, "PushQuestsToServerAsync called.", this);
        var quests = questManager.ActiveQuests.Select(q => new QuestData
        {
            questId = q.Name,
            state = q.Status.ToString()
        }).ToList();
        await DevionGamesServerApi.SetQuestsAsync(quests);
        TD.Info(Tags.Quest, $"Pushed {quests.Count} quests to server.", this);
    }

    // --- Character Sync ---
    public async Task SyncCharactersFromServerAsync()
    {
        TD.Info(Tags.Character, "SyncCharactersFromServerAsync called.", this);
        CharacterManager.LoadCharacters();
        TD.Info(Tags.Character, "CharacterManager.LoadCharacters triggered.", this);
    }
    public Task PushCharactersToServerAsync()
    {
        TD.Info(Tags.Character, "PushCharactersToServerAsync called (stub).", this);
        return Task.CompletedTask;
    }

    // --- Utility ---
    private void SyncContainerFromServer(ItemContainer container, List<ItemData> items)
    {
        TD.Info(Tags.Inventory, $"SyncContainerFromServer: {container?.name ?? "null"} with {items.Count} items.", this);
        foreach (var slot in container.GetComponentsInChildren<Slot>())
        {
            if (!slot.IsEmpty)
            {
                var item = slot.ObservedItem;
                int stack = item.Stack;
                container.RemoveItem(item, stack);
                TD.Verbose(Tags.Inventory, $"Removed {item.Name} x{stack} from {container.name}", this);
            }
        }
        foreach (var item in items)
        {
            var def = InventoryManager.Database.items.FirstOrDefault(i => i.Name == item.itemName);
            if (def != null)
            {
                Item newItem = ScriptableObject.Instantiate(def);
                newItem.Stack = item.amount;
                container.AddItem(newItem);
                TD.Verbose(Tags.Inventory, $"Added {item.itemName} x{item.amount} to {container.name}", this);
            }
            else
            {
                TD.Warning(Tags.Inventory, $"Item def not found: {item.itemName} when syncing {container.name}", this);
            }
        }
        TD.Info(Tags.Inventory, $"SyncContainerFromServer complete for {container.name}", this);
    }

    private List<ItemData> CollectContainerItems(ItemContainer container)
    {
        TD.Info(Tags.Inventory, $"Collecting items from {container?.name ?? "null"}", this);
        var items = new List<ItemData>();
        foreach (var slot in container.GetComponentsInChildren<Slot>())
        {
            if (!slot.IsEmpty)
            {
                var item = slot.ObservedItem;
                items.Add(new ItemData { itemName = item.Name, amount = item.Stack });
                TD.Verbose(Tags.Inventory, $"Collected {item.Name} x{item.Stack}", this);
            }
        }
        TD.Info(Tags.Inventory, $"Collected {items.Count} items from {container?.name ?? "null"}", this);
        return items;
    }

    // --- Composite Sync/Push ---
    public async Task SyncAllFromServerAsync()
    {
        TD.Info(Tags.Network, "SyncAllFromServerAsync started.", this);
        await SyncInventoryFromServerAsync();
        await SyncEquipmentFromServerAsync();
        await SyncBankFromServerAsync();
        await SyncHotbarFromServerAsync();
        await SyncStatsFromServerAsync();
        await SyncQuestsFromServerAsync();
        await SyncCharactersFromServerAsync();
        TD.Info(Tags.Network, "SyncAllFromServerAsync complete.", this);
    }
}

// --- DATA STRUCTURES ---
[System.Serializable]
public struct ItemData
{
    public string itemName;
    public int amount;
}
[System.Serializable]
public struct StatData
{
    public string statName;
    public float value;
}
[System.Serializable]
public struct QuestData
{
    public string questId;
    public string state;
}
[System.Serializable]
public struct CharacterData
{
    public string id;
    public string name;
    public string classId;
}
