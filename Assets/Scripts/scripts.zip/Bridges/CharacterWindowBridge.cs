// Assets/Scripts/Bridges/CharacterWindowBridge.cs

using System.Collections.Generic;
using UnityEngine;
using DevionGames.CharacterSystem;
using Vespeyr.Network; // Or your correct DTO/bridge namespace
using Assets.Scripts.Data;

public class CharacterWindowBridge : MonoBehaviour
{
    [Header("References")]
    public CharacterWindow characterWindow; // Assign in inspector

    [Tooltip("Optional: Prefab mapping by class/job name if needed.")]
    public List<CharacterPrefabMapping> prefabMappings; // See struct below

    /// <summary>
    /// Fetch characters from API and populate Devion Games UI.
    /// </summary>
    public async void PopulateFromServer(string worldKey)
    {
        try
        {
            List<CharacterDTO> apiCharacters = await DVGApiBridge.GetCharacters(worldKey);
            PopulateCharacterList(apiCharacters);
        }
        catch (System.Exception ex)
        {
            Debug.LogError($"[CharacterWindowBridge] Failed to fetch or populate characters: {ex}");
            characterWindow?.Clear();
        }
    }

    /// <summary>
    /// Converts API DTOs into Devion Games Character objects and populates the CharacterWindow.
    /// </summary>
    public void PopulateCharacterList(List<CharacterDTO> apiCharacters)
    {
        if (characterWindow == null)
        {
            Debug.LogError("[CharacterWindowBridge] CharacterWindow reference not set!");
            return;
        }

        characterWindow.Clear();
        if (apiCharacters == null)
            return;

        List<Character> devionCharacters = new List<Character>();

        foreach (var dto in apiCharacters)
        {
            Character newCharacter = ScriptableObject.CreateInstance<Character>();

            // Set base fields
            newCharacter.CharacterName = dto.CharacterName;
            newCharacter.Name = !string.IsNullOrEmpty(dto.Name) ? dto.Name : dto.CharacterName;

            // Gender: must be DevionGames.CharacterSystem.Gender enum (0=Male, 1=Female)
            try
            {
                if (!string.IsNullOrEmpty(dto.Gender))
                {
                    if (System.Enum.TryParse(dto.Gender, true, out Gender genderValue))
                        newCharacter.Gender = genderValue;
                    else
                        newCharacter.Gender = Gender.Male; // fallback
                }
            }
            catch { newCharacter.Gender = Gender.Male; }

            // Description (optional)
            if (!string.IsNullOrEmpty(dto.Description))
                newCharacter.Description = dto.Description;

            // Prefab assignment
            GameObject prefab = null;
            if (prefabMappings != null && prefabMappings.Count > 0 && !string.IsNullOrEmpty(dto.Class))
            {
                var match = prefabMappings.Find(p => p.className == dto.Class);
                if (match != null)
                    prefab = match.prefab;
            }
            // Optionally try to load from Resources using a prefab path in your DTO (if you add one)
            // else if (!string.IsNullOrEmpty(dto.PrefabResourcePath)) prefab = Resources.Load<GameObject>(dto.PrefabResourcePath);

            newCharacter.Prefab = prefab;

            // --- Set custom dynamic properties using SetProperty() ---
            // You can add ANY property with any name here.
            if (!string.IsNullOrEmpty(dto.Class))
                newCharacter.SetProperty("Class", dto.Class);
            if (dto.Level > 0)
                newCharacter.SetProperty("Level", dto.Level);
            if (dto.Experience > 0)
                newCharacter.SetProperty("Experience", dto.Experience);
            if (!string.IsNullOrEmpty(dto.Faction))
                newCharacter.SetProperty("Faction", dto.Faction);

            // Any other custom stats from your backend
            if (dto.Attributes != null)
                newCharacter.SetProperty("Attributes", dto.Attributes);

            // Add to the list
            devionCharacters.Add(newCharacter);
        }

        characterWindow.Add(devionCharacters.ToArray());
    }
}

/// <summary>
/// Maps a class/job name to a prefab.
/// </summary>
[System.Serializable]
public class CharacterPrefabMapping
{
    public string className;
    public GameObject prefab;
}
