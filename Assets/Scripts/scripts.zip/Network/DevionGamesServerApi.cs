﻿using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Networking;
using TagDebugSystem;

public static class DevionGamesServerApi
{
    private static string baseUrl = "http://127.0.0.1:5000/api";
    private static string jwtToken = "";

    public static void SetJwt(string token)
    {
        TD.Info(Tags.Network, $"SetJwt called. Token set: {(!string.IsNullOrEmpty(token) ? "YES" : "NO")}", null);
        jwtToken = token;
    }

    // -------- INVENTORY --------
    public static async Task<List<ItemData>> GetInventoryAsync()
    {
        TD.Info(Tags.Inventory, "GetInventoryAsync called.", null);
        return await GetList<ItemData>($"{baseUrl}/inventory/get");
    }
    public static async Task SetInventoryAsync(List<ItemData> items)
    {
        TD.Info(Tags.Inventory, $"SetInventoryAsync called with {items.Count} items.", null);
        await Post($"{baseUrl}/inventory/set", JsonUtility.ToJson(new ItemListRequest { items = items }));
    }

    // -------- EQUIPMENT --------
    public static async Task<List<ItemData>> GetEquipmentAsync()
    {
        TD.Info(Tags.Inventory, "GetEquipmentAsync called.", null);
        return await GetList<ItemData>($"{baseUrl}/equipment/get");
    }
    public static async Task SetEquipmentAsync(List<ItemData> items)
    {
        TD.Info(Tags.Inventory, $"SetEquipmentAsync called with {items.Count} items.", null);
        await Post($"{baseUrl}/equipment/set", JsonUtility.ToJson(new ItemListRequest { items = items }));
    }

    // -------- BANK --------
    public static async Task<List<ItemData>> GetBankAsync()
    {
        TD.Info(Tags.Inventory, "GetBankAsync called.", null);
        return await GetList<ItemData>($"{baseUrl}/bank/get");
    }
    public static async Task SetBankAsync(List<ItemData> items)
    {
        TD.Info(Tags.Inventory, $"SetBankAsync called with {items.Count} items.", null);
        await Post($"{baseUrl}/bank/set", JsonUtility.ToJson(new ItemListRequest { items = items }));
    }

    // -------- HOTBAR --------
    public static async Task<List<ItemData>> GetHotbarAsync()
    {
        TD.Info(Tags.Inventory, "GetHotbarAsync called.", null);
        return await GetList<ItemData>($"{baseUrl}/hotbar/get");
    }
    public static async Task SetHotbarAsync(List<ItemData> items)
    {
        TD.Info(Tags.Inventory, $"SetHotbarAsync called with {items.Count} items.", null);
        await Post($"{baseUrl}/hotbar/set", JsonUtility.ToJson(new ItemListRequest { items = items }));
    }

    // -------- STATS --------
    public static async Task<List<StatData>> GetStatsAsync()
    {
        TD.Info(Tags.Stats, "GetStatsAsync called.", null);
        return await GetList<StatData>($"{baseUrl}/stats/get");
    }
    public static async Task SetStatsAsync(List<StatData> stats)
    {
        TD.Info(Tags.Stats, $"SetStatsAsync called with {stats.Count} stats.", null);
        await Post($"{baseUrl}/stats/set", JsonUtility.ToJson(new StatListRequest { stats = stats }));
    }

    // -------- QUESTS --------
    public static async Task<List<QuestData>> GetQuestsAsync()
    {
        TD.Info(Tags.Quest, "GetQuestsAsync called.", null);
        return await GetList<QuestData>($"{baseUrl}/quests/get");
    }
    public static async Task SetQuestsAsync(List<QuestData> quests)
    {
        TD.Info(Tags.Quest, $"SetQuestsAsync called with {quests.Count} quests.", null);
        await Post($"{baseUrl}/quests/set", JsonUtility.ToJson(new QuestListRequest { quests = quests }));
    }

    // -------- CHARACTERS --------
    public static async Task<List<CharacterData>> GetCharactersAsync()
    {
        TD.Info(Tags.Character, "GetCharactersAsync called.", null);
        return await GetList<CharacterData>($"{baseUrl}/characters/get");
    }
    public static async Task SetCharactersAsync(List<CharacterData> chars)
    {
        TD.Info(Tags.Character, $"SetCharactersAsync called with {chars.Count} characters.", null);
        await Post($"{baseUrl}/characters/set", JsonUtility.ToJson(new CharacterListRequest { characters = chars }));
    }

    // ----------- UTILITY GENERICS -----------
    private static async Task<List<T>> GetList<T>(string url)
    {
        TD.Verbose(Tags.Network, $"GetList<{typeof(T).Name}> requesting: {url}", null);
        using (UnityWebRequest req = UnityWebRequest.Get(url))
        {
            req.SetRequestHeader("Content-Type", "application/json");
            if (!string.IsNullOrEmpty(jwtToken))
                req.SetRequestHeader("Authorization", $"Bearer {jwtToken}");
            await req.SendWebRequest();
            if (req.result == UnityWebRequest.Result.Success)
            {
                string json = req.downloadHandler.text;
                TD.Verbose(Tags.Network, $"GetList<{typeof(T).Name}> success: {json}", null);
                return JsonUtility.FromJson<ListWrapper<T>>(json).list;
            }
            else
            {
                TD.Error(Tags.Network, $"GetList<{typeof(T).Name}> failed: {req.error}", null);
                return new List<T>();
            }
        }
    }

    private static async Task Post(string url, string json)
    {
        TD.Verbose(Tags.Network, $"POST {url} with data: {json}", null);
        using (UnityWebRequest req = new UnityWebRequest(url, "POST"))
        {
            byte[] bodyRaw = Encoding.UTF8.GetBytes(json);
            req.uploadHandler = new UploadHandlerRaw(bodyRaw);
            req.downloadHandler = new DownloadHandlerBuffer();
            req.SetRequestHeader("Content-Type", "application/json");
            if (!string.IsNullOrEmpty(jwtToken))
                req.SetRequestHeader("Authorization", $"Bearer {jwtToken}");
            await req.SendWebRequest();
            if (req.result != UnityWebRequest.Result.Success)
                TD.Error(Tags.Network, $"POST {url} failed: {req.error}", null);
            else
                TD.Verbose(Tags.Network, $"POST {url} succeeded.", null);
        }
    }

    // ---------- STRUCTS FOR SERIALIZATION ----------
    [System.Serializable]
    private class ListWrapper<T>
    {
        public List<T> list;
    }
    [System.Serializable]
    public class ItemListRequest { public List<ItemData> items; }
    [System.Serializable]
    public class StatListRequest { public List<StatData> stats; }
    [System.Serializable]
    public class QuestListRequest { public List<QuestData> quests; }
    [System.Serializable]
    public class CharacterListRequest { public List<CharacterData> characters; }
}
