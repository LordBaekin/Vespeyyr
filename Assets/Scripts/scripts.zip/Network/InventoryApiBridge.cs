﻿using System.Collections;
using UnityEngine;
using UnityEngine.Networking;
using System;
using TagDebugSystem;

public static class InventoryApiBridge
{
    // Download inventory from server
    public static IEnumerator GetInventory(
        string authToken, string worldKey, string saveKey, string sceneName,
        Action<InventoryDTO> onCompleted)
    {
        string url = $"http://127.0.0.1:5000/inventory/{worldKey}/{saveKey}/{sceneName}";
        TD.Info(Tags.Inventory, $"GetInventory called for url {url}", null);
        using (UnityWebRequest www = UnityWebRequest.Get(url))
        {
            www.SetRequestHeader("Authorization", $"Bearer {authToken}");
            yield return www.SendWebRequest();

            if (www.result == UnityWebRequest.Result.Success)
            {
                TD.Verbose(Tags.Inventory, $"Inventory received: {www.downloadHandler.text}", null);
                var dto = JsonUtility.FromJson<InventoryDTO>(www.downloadHandler.text);
                onCompleted?.Invoke(dto);
            }
            else
            {
                TD.Warning(Tags.Inventory, $"Failed to get inventory: {www.error}", null);
                onCompleted?.Invoke(null);
            }
        }
    }

    // Upload inventory to server
    public static IEnumerator SaveInventory(
        string authToken, string worldKey, string saveKey, string sceneName, InventoryDTO dto,
        Action<bool> onCompleted)
    {
        string url = "http://127.0.0.1:5000/inventory";
        string jsonData = JsonUtility.ToJson(dto);
        TD.Info(Tags.Inventory, $"SaveInventory called for url {url}", null);
        using (UnityWebRequest www = UnityWebRequest.PostWwwForm(url, jsonData))
        {
            www.SetRequestHeader("Authorization", $"Bearer {authToken}");
            www.uploadHandler = new UploadHandlerRaw(System.Text.Encoding.UTF8.GetBytes(jsonData));
            www.downloadHandler = new DownloadHandlerBuffer();
            www.SetRequestHeader("Content-Type", "application/json");
            yield return www.SendWebRequest();

            if (www.result == UnityWebRequest.Result.Success)
            {
                TD.Info(Tags.Inventory, $"Inventory saved successfully.", null);
                onCompleted?.Invoke(true);
            }
            else
            {
                TD.Warning(Tags.Inventory, $"Failed to save inventory: {www.error}", null);
                onCompleted?.Invoke(false);
            }
        }
    }
}
