﻿using DevionGames.CharacterSystem.Configuration;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Assertions;
using System;

namespace DevionGames.CharacterSystem
{
    public class CharacterManager : MonoBehaviour
    {
        /// Don't destroy this object instance when loading new scenes.
        /// </summary>
        public bool dontDestroyOnLoad = true;

        private static CharacterManager m_Current;

        /// <summary>
        /// The InventoryManager singleton object. This object is set inside Awake()
        /// </summary>
        public static CharacterManager current
        {
            get
            {
                Assert.IsNotNull(m_Current, "Requires a Character Manager.Create one from Tools > Devion Games > Character System > Create Character Manager!");
                return m_Current;
            }
        }

        [SerializeField]
        private CharacterDatabase m_Database = null;

        /// <summary>
        /// Gets the item database. Configurate it inside the editor.
        /// </summary>
        /// <value>The database.</value>
        public static CharacterDatabase Database
        {
            get
            {
                if (CharacterManager.current != null)
                {
                    Assert.IsNotNull(CharacterManager.current.m_Database, "Please assign CharacterDatabase to the Character Manager!");
                    return CharacterManager.current.m_Database;
                }
                return null;
            }
        }

        private static Default m_DefaultSettings;
        public static Default DefaultSettings
        {
            get
            {
                if (m_DefaultSettings == null)
                {
                    m_DefaultSettings = GetSetting<Default>();
                }
                return m_DefaultSettings;
            }
        }

        private static UI m_UI;
        public static UI UI
        {
            get
            {
                if (m_UI == null)
                {
                    m_UI = GetSetting<UI>();
                }
                return m_UI;
            }
        }

        private static Notifications m_Notifications;
        public static Notifications Notifications
        {
            get
            {
                if (m_Notifications == null)
                {
                    m_Notifications = GetSetting<Notifications>();
                }
                return m_Notifications;
            }
        }

        private static SavingLoading m_SavingLoading;
        public static SavingLoading SavingLoading
        {
            get
            {
                if (m_SavingLoading == null)
                {
                    m_SavingLoading = GetSetting<SavingLoading>();
                }
                return m_SavingLoading;
            }
        }

        private static T GetSetting<T>() where T : Configuration.Settings
        {
            if (CharacterManager.Database != null)
            {
                return (T)CharacterManager.Database.settings.Where(x => x.GetType() == typeof(T)).FirstOrDefault();
            }
            return default(T);
        }

        private Character m_SelectedCharacter;
        public Character SelectedCharacter
        {
            get { return this.m_SelectedCharacter; }
        }

        /// <summary>
        /// Awake is called when the script instance is being loaded.
        /// </summary>
        private void Awake()
        {
            if (CharacterManager.m_Current != null)
            {
                // Debug.Log("Multiple Character Manager in scene...this is not supported. Destroying instance!");
                Destroy(gameObject);
                return;
            }
            else
            {
                CharacterManager.m_Current = this;
                if (dontDestroyOnLoad)
                {
                    if (transform.parent != null)
                    {
                        if (CharacterManager.DefaultSettings.debugMessages)
                            Debug.Log("Character Manager with DontDestroyOnLoad can't be a child transform. Unparent!");
                        transform.parent = null;
                    }
                    DontDestroyOnLoad(gameObject);
                }

                // Register for data processing event from interceptor
                EventHandler.Register<string>("OnCharacterManagerProcessData", ProcessCharacterData);

                Debug.Log("Character Manager initialized.");
            }
        }

        private void OnDestroy()
        {
            EventHandler.Unregister<string>("OnCharacterManagerProcessData", ProcessCharacterData);
        }

        /// <summary>
        /// Process character data (called by interceptor for local loading)
        /// </summary>
        private static void ProcessCharacterData(string data)
        {
            if (string.IsNullOrEmpty(data))
            {
                Debug.Log("[CharacterManager] No character data to process");
                return;
            }

            List<object> l = MiniJSON.Deserialize(data) as List<object>;
            for (int i = 0; i < l.Count; i++)
            {
                Dictionary<string, object> characterData = l[i] as Dictionary<string, object>;
                EventHandler.Execute("OnCharacterDataLoaded", characterData);
            }

            List<Character> list = JsonSerializer.Deserialize<Character>(data);
            for (int i = 0; i < list.Count; i++)
            {
                Character character = list[i];
                EventHandler.Execute("OnCharacterLoaded", character);
            }
        }

        public static void StartPlayScene(Character selected)
        {
            CharacterManager.current.m_SelectedCharacter = selected;

            // Get both character ID and name properly
            string characterId = selected.FindProperty("CharacterId")?.stringValue;
            string characterName = selected.CharacterName;  // This is the player-entered name

            // If no proper CharacterId exists, use character name as fallback
            if (string.IsNullOrEmpty(characterId))
            {
                characterId = characterName;
                Debug.LogWarning($"[CharacterManager] No CharacterId found for character '{characterName}', using name as ID");
            }

            // Ensure world context is set first
            string worldKey = ServerWorldEvents.CurrentWorldKey;
            if (string.IsNullOrEmpty(worldKey))
            {
                // Fallback to PlayerPrefs if ServerWorldEvents not set
                worldKey = PlayerPrefs.GetString("selected_server", "");
                if (!string.IsNullOrEmpty(worldKey))
                {
                    // Update ServerWorldEvents with the fallback
                    string worldName = PlayerPrefs.GetString("selected_server_name", worldKey);
                    ServerWorldEvents.SetCurrentWorld(worldKey, worldName);
                    DevionGamesAdapter.SetWorldContext(worldKey);
                }
            }
            Debug.Log($"[CharacterManager] About to set context:");
            Debug.Log($"  - characterId: '{characterId}'");
            Debug.Log($"  - characterName: '{characterName}'");
            Debug.Log($"  - selected.CharacterName: '{selected.CharacterName}'");

            // Now set character context with both ID and name
            DevionGamesAdapter.SetCharacterContext(characterId, characterName);

            // Also ensure auth token is set
            string token = PlayerPrefs.GetString("jwt_token", "");
            if (!string.IsNullOrEmpty(token))
            {
                DevionGamesAdapter.SetAuthToken(token);
            }

            // Keep existing PlayerPrefs for compatibility
            PlayerPrefs.SetString("Player", selected.CharacterName);
            PlayerPrefs.SetString("Profession", selected.Name);

            string scene = selected.FindProperty("Scene")?.stringValue;
            if (string.IsNullOrEmpty(scene))
            {
                scene = CharacterManager.DefaultSettings.playScene;
            }

            if (CharacterManager.DefaultSettings.debugMessages)
                Debug.Log("[Character System] Loading scene " + scene + " for " + selected.CharacterName);

            UnityEngine.SceneManagement.SceneManager.activeSceneChanged += ChangedActiveScene;
            UnityEngine.SceneManagement.SceneManager.LoadScene(scene);
        }

        private static void ChangedActiveScene(UnityEngine.SceneManagement.Scene current, UnityEngine.SceneManagement.Scene next)
        {
            Vector3 position = CharacterManager.current.m_SelectedCharacter.FindProperty("Spawnpoint").vector3Value;
            GameObject player = GameObject.FindGameObjectWithTag("Player");
            //Player already in scene
            if (player != null)
            {
                //Is it the player prefab we selected?
                if (player.name == CharacterManager.current.m_SelectedCharacter.Prefab.name)
                {
                    return;
                }
                DestroyImmediate(player);
            }

            player = GameObject.Instantiate(CharacterManager.current.m_SelectedCharacter.Prefab, position, Quaternion.identity);
            player.name = player.name.Replace("(Clone)", "").Trim();
        }

        public static void CreateCharacter(Character character)
        {
            // Fire event to allow server interception for creation
            EventHandler.Execute("OnCharacterManagerCreateCharacter", character);

            // Use DevionGamesAdapter for local storage (interceptor handles server if needed)
            DevionGamesAdapter.LoadCharacterData((existingData) => {
                List<Character> list = string.IsNullOrEmpty(existingData) ?
                    new List<Character>() :
                    JsonSerializer.Deserialize<Character>(existingData);

                // Check for duplicate names
                for (int i = 0; i < list.Count; i++)
                {
                    if (list[i].CharacterName == character.CharacterName)
                    {
                        EventHandler.Execute("OnFailedToCreateCharacter", character);
                        return;
                    }
                }

                // Add new character
                list.Add(character);
                string data = JsonSerializer.Serialize(list.ToArray());

                // Save using DevionGamesAdapter (local only)
                DevionGamesAdapter.SaveCharacterData(data);

                EventHandler.Execute("OnCharacterCreated", character);
            });
        }

        public static void LoadCharacters()
        {
            // Fire event to allow server interception for loading
            EventHandler.Execute("OnCharacterManagerLoadCharacters");
        }

        public static void DeleteCharacter(Character character)
        {
            // Fire event to allow server interception for deletion
            EventHandler.Execute("OnCharacterManagerDeleteCharacter", character);

            // Use DevionGamesAdapter for local storage (interceptor handles server if needed)
            DevionGamesAdapter.LoadCharacterData((existingData) => {
                if (string.IsNullOrEmpty(existingData)) return;

                List<Character> list = JsonSerializer.Deserialize<Character>(existingData);

                // Remove character and save updated list
                string data = JsonSerializer.Serialize(list.Where(x => x.CharacterName != character.CharacterName).ToArray());
                DevionGamesAdapter.SaveCharacterData(data);

                DeleteInventorySystemForCharacter(character.CharacterName);
                DeleteStatSystemForCharacter(character.CharacterName);
                EventHandler.Execute("OnCharacterDeleted", character);
            });
        }

        private static void DeleteInventorySystemForCharacter(string character)
        {
            PlayerPrefs.DeleteKey(character + ".UI");
            List<string> scenes = PlayerPrefs.GetString(character + ".Scenes").Split(';').ToList();
            scenes.RemoveAll(x => string.IsNullOrEmpty(x));
            for (int i = 0; i < scenes.Count; i++)
            {
                PlayerPrefs.DeleteKey(character + "." + scenes[i]);
            }
            PlayerPrefs.DeleteKey(character + ".Scenes");
        }

        private static void DeleteStatSystemForCharacter(string character)
        {
            PlayerPrefs.DeleteKey(character + ".Stats");
            List<string> keys = PlayerPrefs.GetString("StatSystemSavedKeys").Split(';').ToList();
            keys.RemoveAll(x => string.IsNullOrEmpty(x));
            List<string> allKeys = new List<string>(keys);
            allKeys.Remove(character);
            PlayerPrefs.SetString("StatSystemSavedKeys", string.Join(";", allKeys));
        }
    }
}