﻿// Assets/Devion Games/Character System/Scripts/Runtime/DevionGamesAdapter.cs
using System;
using System.Collections.Generic;
using UnityEngine;

namespace DevionGames.CharacterSystem
{
    /// <summary>
    /// DevionGamesAdapter integrated with your existing FlowManager and ServerWorldEvents.
    /// Preserves all original PlayerPrefs fallback logic, plus hybrid persistence when enabled.
    /// </summary>
    public static class DevionGamesAdapter
    {
        private static HybridPersistenceBridge Bridge => HybridPersistenceBridge.Instance;

        /// <summary>
        /// The server‐assigned CharacterId currently in context.
        /// </summary>
        public static string CurrentCharacterId =>
            Bridge != null
                ? Bridge.currentCharacterId
                : PlayerPrefs.GetString("CurrentCharacterID", "");

        /// <summary>
        /// The world key currently in context.
        /// </summary>
        public static string CurrentWorldKey =>
            Bridge != null
                ? Bridge.currentWorldKey
                : PlayerPrefs.GetString("CurrentWorldKey", "DefaultWorld");

        // ===================== INVENTORY SYSTEM ADAPTER =====================

        public static void SaveInventoryData(string key, string scene, string uiData, string sceneData = "")
        {
            if (ShouldUseHybridBridge())
            {
                SetBridgeContext();
                if (scene == "UI")
                    Bridge.SaveInventoryData("UI", uiData, "");
                else if (scene == "Scenes")
                    Bridge.SaveInventoryData("Scenes", uiData, "");
                else
                    Bridge.SaveInventoryData(scene, uiData, sceneData);
            }
            else
            {
                // Original PlayerPrefs fallback
                if (scene == "UI")
                    PlayerPrefs.SetString($"{key}.UI", uiData);
                else if (scene == "Scenes")
                    PlayerPrefs.SetString($"{key}.Scenes", uiData);
                else
                {
                    PlayerPrefs.SetString($"{key}.{scene}", uiData);
                    if (!string.IsNullOrEmpty(sceneData))
                        PlayerPrefs.SetString($"{key}.{scene}_scene", sceneData);
                }
                PlayerPrefs.Save();
            }
        }

        public static void LoadInventoryData(string key, string scene, System.Action<string, string> callback)
        {
            if (ShouldUseHybridBridge())
            {
                SetBridgeContext();
                Bridge.LoadInventoryData(scene, callback);
            }
            else
            {
                // Original PlayerPrefs fallback
                string uiData = "", sceneData = "";
                if (scene == "UI")
                    uiData = PlayerPrefs.GetString($"{key}.UI", "");
                else if (scene == "Scenes")
                    uiData = PlayerPrefs.GetString($"{key}.Scenes", "");
                else
                {
                    uiData = PlayerPrefs.GetString($"{key}.{scene}", "");
                    sceneData = PlayerPrefs.GetString($"{key}.{scene}_scene", "");
                }
                callback(uiData, sceneData);
            }
        }

        public static void LoadInventorySystemKeys(System.Action<List<string>> callback)
        {
            if (ShouldUseHybridBridge())
                Bridge.LoadString("InventorySystemSavedKeys", "", data => callback(ParseKeyData(data)));
            else
                callback(ParseKeyData(PlayerPrefs.GetString("InventorySystemSavedKeys", "")));
        }

        public static void SaveInventorySystemKeys(List<string> keys)
        {
            var data = string.Join(";", keys);
            if (ShouldUseHybridBridge())
                Bridge.SaveString("InventorySystemSavedKeys", data);
            else
            {
                PlayerPrefs.SetString("InventorySystemSavedKeys", data);
                PlayerPrefs.Save();
            }
        }



        //
        // —— GENERIC STRING SAVE/LOAD —— 
        //

        /// <summary>
        /// Save a simple key/value string via server or PlayerPrefs.
        /// </summary>
        public static void SaveString(string key, string value)
        {
            if (ShouldUseHybridBridge())
            {
                SetBridgeContext();
                Bridge.SaveString(key, value);
            }
            else
            {
                PlayerPrefs.SetString(key, value);
                PlayerPrefs.Save();
            }
        }

        /// <summary>
        /// Load a simple key/value string via server or PlayerPrefs.
        /// </summary>
        public static void LoadString(string key, string defaultValue, Action<string> callback)
        {
            if (ShouldUseHybridBridge())
            {
                SetBridgeContext();
                Bridge.LoadString(key, defaultValue, callback);
            }
            else
            {
                callback(PlayerPrefs.GetString(key, defaultValue));
            }
        }



        // ===================== QUEST SYSTEM ADAPTER =====================

        public static void SaveQuestData(string key, string activeQuests, string completedQuests, string failedQuests)
        {
            if (ShouldUseHybridBridge())
            {
                SetBridgeContext();
                Bridge.SaveQuestData(activeQuests, completedQuests, failedQuests);
            }
            else
            {
                PlayerPrefs.SetString($"{key}.ActiveQuests", activeQuests);
                PlayerPrefs.SetString($"{key}.CompletedQuests", completedQuests);
                PlayerPrefs.SetString($"{key}.FailedQuests", failedQuests);
                PlayerPrefs.Save();
            }
        }

        public static void LoadQuestData(string key, System.Action<string, string, string> callback)
        {
            if (ShouldUseHybridBridge())
            {
                SetBridgeContext();
                Bridge.LoadQuestData(callback);
            }
            else
            {
                var a = PlayerPrefs.GetString($"{key}.ActiveQuests", "");
                var c = PlayerPrefs.GetString($"{key}.CompletedQuests", "");
                var f = PlayerPrefs.GetString($"{key}.FailedQuests", "");
                callback(a, c, f);
            }
        }

        public static void LoadQuestSystemKeys(System.Action<List<string>> callback)
        {
            if (ShouldUseHybridBridge())
                Bridge.LoadString("QuestSystemSavedKeys", "", data => callback(ParseKeyData(data)));
            else
                callback(ParseKeyData(PlayerPrefs.GetString("QuestSystemSavedKeys", "")));
        }

        public static void SaveQuestSystemKeys(List<string> keys)
        {
            var data = string.Join(";", keys);
            if (ShouldUseHybridBridge())
                Bridge.SaveString("QuestSystemSavedKeys", data);
            else
            {
                PlayerPrefs.SetString("QuestSystemSavedKeys", data);
                PlayerPrefs.Save();
            }
        }

        // ===================== STATS SYSTEM ADAPTER =====================

        public static void SaveStatsData(string key, string statsJson)
        {
            if (ShouldUseHybridBridge())
            {
                SetBridgeContext();
                Bridge.SaveStatsData(statsJson);
            }
            else
            {
                PlayerPrefs.SetString($"{key}.Stats", statsJson);
                PlayerPrefs.Save();
            }
        }

        public static void LoadStatsData(string key, System.Action<string> callback)
        {
            if (ShouldUseHybridBridge())
            {
                SetBridgeContext();
                Bridge.LoadStatsData(callback);
            }
            else
                callback(PlayerPrefs.GetString($"{key}.Stats", ""));
        }

        public static void LoadStatsSystemKeys(System.Action<List<string>> callback)
        {
            if (ShouldUseHybridBridge())
                Bridge.LoadString("StatSystemSavedKeys", "", data => callback(ParseKeyData(data)));
            else
                callback(ParseKeyData(PlayerPrefs.GetString("StatSystemSavedKeys", "")));
        }

        public static void SaveStatsSystemKeys(List<string> keys)
        {
            var data = string.Join(";", keys);
            if (ShouldUseHybridBridge())
                Bridge.SaveString("StatSystemSavedKeys", data);
            else
            {
                PlayerPrefs.SetString("StatSystemSavedKeys", data);
                PlayerPrefs.Save();
            }
        }

        // ===================== CHARACTER SYSTEM ADAPTER =====================

        public static void SaveCharacterData(string characterJson)
        {
            if (ShouldUseHybridBridge())
            {
                SetBridgeContext();
                Bridge.SaveCharacterData(characterJson);
            }
            else
            {
                var account = PlayerPrefs.GetString("Account", "Player");
                PlayerPrefs.SetString(account, characterJson);
                PlayerPrefs.Save();
            }
        }

        public static void LoadCharacterData(System.Action<string> callback)
        {
            if (ShouldUseHybridBridge())
            {
                SetBridgeContext();
                Bridge.LoadCharacterData(callback);
            }
            else
            {
                var account = PlayerPrefs.GetString("Account", "Player");
                callback(PlayerPrefs.GetString(account, ""));
            }
        }

        // ===================== CONTEXT MANAGEMENT =====================

        /// <summary>Sets the bridge context to the current world/character.</summary>
        private static void SetBridgeContext()
        {
            if (Bridge == null) return;
            Bridge.SetContext(CurrentWorldKey, CurrentCharacterId);
        }

        /// <summary>Should we route through the server or fall back to PlayerPrefs?</summary>
        private static bool ShouldUseHybridBridge()
        {
            return Bridge != null
                && Bridge.providerAsset != null
                && Bridge.providerAsset.currentProvider
                       != SaveProviderSelectorSO.SaveProvider.PlayerPrefs;
        }

        private static List<string> ParseKeyData(string keyData)
        {
            var list = new List<string>();
            if (!string.IsNullOrEmpty(keyData))
            {
                list.AddRange(keyData.Split(';'));
                list.RemoveAll(x => string.IsNullOrEmpty(x));
            }
            return list;
        }

        // ===================== PUBLIC API FOR FLOW MANAGER =====================

        public static void SetCharacterContext(string characterId, string characterName)
        {
            Debug.Log($"[DevionGamesAdapter] SetCharacterContext called with: ID='{characterId}', Name='{characterName}'");
            if (Bridge == null) return;

            if (string.IsNullOrEmpty(characterId))
            {
                Debug.LogError("[DevionGamesAdapter] CharacterId is null or empty!");
                return;
            }
            if (string.IsNullOrEmpty(characterName))
            {
                Debug.LogWarning("[DevionGamesAdapter] CharacterName empty, using ID fallback");
                characterName = characterId;
            }

            PlayerPrefs.SetString("CurrentCharacterID", characterId);
            PlayerPrefs.SetString("CurrentCharacterName", characterName);
            PlayerPrefs.Save();

            // Update context immediately
            Bridge.SetContext(CurrentWorldKey, characterId);
            Debug.Log($"[DevionGamesAdapter] Character context set: World={CurrentWorldKey}, CharacterID={characterId}, CharacterName={characterName}");
        }

        public static void SetCharacterContext(string characterIdOrName)
        {
            Debug.LogWarning($"[DevionGamesAdapter] Using single value for both ID and Name: {characterIdOrName}");
            SetCharacterContext(characterIdOrName, characterIdOrName);
        }

        public static void SetWorldContext(string worldKey)
        {
            if (Bridge == null) return;
            PlayerPrefs.SetString("CurrentWorldKey", worldKey);
            PlayerPrefs.Save();
            Bridge.SetContext(worldKey, CurrentCharacterId);
            Debug.Log($"[DevionGamesAdapter] World context set: World={worldKey}, Character={CurrentCharacterId}");
        }

        public static void SetAuthToken(string token)
        {
            Bridge?.SetAuthToken(token);
            Debug.Log($"[DevionGamesAdapter] Auth token set for hybrid bridge");
        }

        public static bool IsHybridBridgeAvailable()
            => Bridge != null && Bridge.providerAsset != null;

        public static SaveProviderSelectorSO.SaveProvider GetCurrentProvider()
            => Bridge?.providerAsset?.currentProvider
               ?? SaveProviderSelectorSO.SaveProvider.PlayerPrefs;
    }
}
